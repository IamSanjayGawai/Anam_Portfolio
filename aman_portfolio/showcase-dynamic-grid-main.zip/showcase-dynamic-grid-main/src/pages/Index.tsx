
import Portfolio from "@/components/Portfolio";

const Index = () => {
  return <Portfolio />;
};

export default Index;
